package com.enyaelvis.day14_bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day14BankApplicationTests {

	@Test
	void contextLoads() {
	}

}
